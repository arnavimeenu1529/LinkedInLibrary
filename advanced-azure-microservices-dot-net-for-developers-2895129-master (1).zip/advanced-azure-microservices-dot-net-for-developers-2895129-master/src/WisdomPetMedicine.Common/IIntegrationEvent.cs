﻿namespace WisdomPetMedicine.Common
{
    public interface IIntegrationEvent
    {
    }
}
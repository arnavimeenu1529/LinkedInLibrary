﻿namespace WisdomPetMedicine.Common
{
    public interface IDomainEvent
    {
    }
}
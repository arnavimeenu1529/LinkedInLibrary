﻿using System;

namespace WisdomPetMedicine.Pet.Api.Commands
{
    public class FlagForAdoptionCommand
    {
        public Guid Id { get; set; }
    }
}
﻿using System;

namespace WisdomPetMedicine.Pet.Api.Commands
{
    public class TransferToHospitalCommand
    {
        public Guid Id { get; set; }
    }
}
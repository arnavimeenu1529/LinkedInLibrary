﻿using System;

namespace WisdomPetMedicine.Hospital.Api.Commands
{
    public class AdmitPatientCommand
    {
        public Guid Id { get; set; }
    }
}
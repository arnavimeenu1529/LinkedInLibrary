﻿using System;

namespace WisdomPetMedicine.Hospital.Api.Commands
{
    public class DischargePatientCommand
    {
        public Guid Id { get; set; }
    }
}
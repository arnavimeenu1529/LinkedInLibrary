﻿namespace WisdomPetMedicine.Hospital.Domain.ValueObjects
{
    public enum PatientStatus
    {
        Pending,
        Admitted,
        Discharged
    }
}
﻿namespace Ecomm.Models
{
    public class OrderDetail
    {
        public string User { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
    }
}

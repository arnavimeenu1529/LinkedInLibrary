﻿namespace ReportService
{
    public class Report
    {
        public string ProductName { get; set; }
        public int Count { get; set; }
    }
}
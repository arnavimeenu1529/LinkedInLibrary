﻿namespace ReportService
{
    public class Order
    {
        public string User { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
    }
}
